import os

filename = input("Input file name: ")
command = input("Input command: ")

os.system(f"exiftool -Comment=$(echo {command}|base64) {filename}")